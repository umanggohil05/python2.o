f_temps = [3, 50, 77, 104, 212]  
c_temps = [(f - 32) * 5/9 for f in f_temps]
print(c_temps)
