strings = ["apple", "banana", "cherry"]
print([s.upper() for s in strings])
