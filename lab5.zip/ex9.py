list1 = [1, 8, 3, 7, 5, 6]
list2 = [4, 5, 6, 7, 8, 9]

list3 = [x for x in list1 if x not in list2]

print(list3)  
