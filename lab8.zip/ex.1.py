L1= ['rose', 'lotus', 'mohan', 'sohan' ]
S1 = set ()
for i in L1 :
    S1.add(i.upper())
print(S1)
print(type(L1))
