kg = int(input())
print(kg * 1000)