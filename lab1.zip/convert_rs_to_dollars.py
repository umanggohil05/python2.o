rs = int(input())
print(rs / 48)