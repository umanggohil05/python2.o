dollars = int(input())
print(dollars * 48 / 70)