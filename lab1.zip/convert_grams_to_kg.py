grams = int(input())
print(grams / 1000)