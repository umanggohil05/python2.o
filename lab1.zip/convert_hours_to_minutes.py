hours = int(input())
print(hours * 60)