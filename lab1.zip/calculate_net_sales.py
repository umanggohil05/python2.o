gross_sales = float(input())
print(gross_sales * 0.90)