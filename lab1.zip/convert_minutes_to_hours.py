minutes = int(input())
print(minutes / 60)