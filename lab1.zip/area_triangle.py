h = float(input())
l = float(input())
print(0.5 * h * l)