gross = float(input())
allowance = gross * 0.10
deduction = gross * 0.03
print(gross + allowance - deduction)