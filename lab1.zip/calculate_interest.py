p = float(input())
r = float(input())
n = float(input())
print((p * r * n) / 100)