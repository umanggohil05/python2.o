r = float(input())
print((22/7) * r**2)