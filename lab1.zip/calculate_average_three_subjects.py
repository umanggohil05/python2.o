s1 = float(input())
s2 = float(input())
s3 = float(input())
total = s1 + s2 + s3
print(total / 3, total)