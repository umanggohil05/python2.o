l = float(input())
b = float(input())
print(l*b, 2*(l+b))