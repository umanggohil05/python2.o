dollars = int(input())
print(dollars * 48)