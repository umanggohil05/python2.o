l = float(input())
print(l**2, 4*l)