bytes = int(input())
print(bytes / 1024, bytes / (1024**2), bytes / (1024**3))