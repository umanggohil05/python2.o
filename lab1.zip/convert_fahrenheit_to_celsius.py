f = float(input())
print((f - 32) * 5/9)