c = float(input())
print((9/5 * c) + 32)