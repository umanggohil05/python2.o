dict1 = {'a': 1, 'b': 2}
dict2 = {'c': 3, 'd': 4}
dict3 = {'e': 5, 'f': 6}

dict4 = dict1.copy()  
dict4.update(dict2)
dict4.update(dict3)

print(dict4)
