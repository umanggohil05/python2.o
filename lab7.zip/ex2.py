dict = {}

if not dict:
    print("The dictionary is empty")
else:
    print("The dictionary is not empty")
