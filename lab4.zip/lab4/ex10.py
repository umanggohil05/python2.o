n = int(input())  
a, b = 0, 1  
print(a, b, *[ (a := b, b := a + b)[0] for _ in range(n-2) ])
