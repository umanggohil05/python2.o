from math import factorial
print(factorial(int(input("Enter number: "))))
