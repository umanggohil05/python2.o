
print("UPPERCASE ALPHABETS:")
for i in range(65,91):
    print(chr(i), end=' ')  
print()  

print("lowercase alphabets:")
for i in range(97, 123):
    print(chr(i), end=' ')  
print() 
