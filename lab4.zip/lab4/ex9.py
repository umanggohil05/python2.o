print(*range(int(input()),0,-1))
