l=int(input())
b=int(input())
if l*b>2*(l+b):
    print("area is greater than perimeter.")
else:
        print("perimeter is greater than area.")
        
