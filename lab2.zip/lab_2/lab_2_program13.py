x=int(input("Enter the digit from 0-19:"))
if x==0 :
    print("the given value in word is ZERO")
elif x==1 :
    print("the given value in word is ONE")
    
elif x==2 :
    print("the given value in word is TWO")
elif x==3 :
    print("the given value in word is THREE")
elif x==4 :
    print("the given value in word is FOUR")
elif x==5 :
    print("the given value in word is FIVE")
elif x==6 :
    print("the given value in word is SIX")
elif x==7 :
    print("the given value in word is SEVEN")
elif x==8 :
    print("the given value in word is EIGHT")
elif x==9 :
    print("the given value in word is NINE")
elif x==10 :
    print("the given value in word is TEN")
elif x==11:
    print("the given value in word is ELEVEN")
elif x==12:
    print("the given value in word is TWELVE")
elif x==13:
    print("the given value in word is THIRTEEN")
elif x==14 :
    print("the given value in word is FOURTEEN")
elif x==15 :
    print("the given value in word is FIFTEEN")
elif x==16:
    print("the given value in word is SIXTEEN")
elif x==17:
    print("the given value in word is SEVENTEEN")
elif x==18:
    print("the given value in word is EIGHTEEN")
elif x==19:
    print("the given value in word is NINETEEN")
else:
    print("the given value is not in range provided")
    


































    
       
