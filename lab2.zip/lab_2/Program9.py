X=int(input())
if X>0:
    print(X)
if X<0:
    print((-1)*X)
    
