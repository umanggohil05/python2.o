a=int(input("Enter the First number"))
b=int(input("Enter the second number"))
print('a')
print('b')
if (a>b):
    print('a is greter')
else:
    print('b is greater')