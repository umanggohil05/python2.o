a=int(input("Enter the First number"))
if (a%2)==0:
    print('enter number is odd')
else:
    print('Enter number is even')