a=int(input("Enter the number"))
if(a%10)==0:
    print("Number is divisibal by 10")
else:
    print("Number is not divisibal by 10")