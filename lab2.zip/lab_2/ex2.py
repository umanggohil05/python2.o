a=int(input("Enter the a"))
b=int(input("Enter the b"))
c=int(input("Enter the c"))
print(a)
print(b)
print(c)
if(a>b) and (a>c):
    print('Largest number is a')
elif(b>a) and (b>c):
    print('Largest number is b')
elif(c>a) and (c>a):
    print('Largest number is c')
