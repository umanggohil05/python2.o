num=int(input())
numdigits:len(num)
