a=int(input("Enter Age"))
if(a<=18):
    print("you are in Minor")
else:
    print("You are in Major")