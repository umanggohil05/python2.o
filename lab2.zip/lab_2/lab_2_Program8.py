a=int(input("Enter value of angle from 0 to 180:"))
b=int(input("Enter value of angle from 0 to 180:"))
c=int(input("Enter value of angle from 0 to 180:"))
if a+b+c==180 :
      print("The given angle are forming a triangle")
else :
          print("The given angle are not forming a triangle")
