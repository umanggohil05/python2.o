X=int(input())

if X%4==0:
    print("It is Leap year.")
else:
        print("It is not a leap year.")
